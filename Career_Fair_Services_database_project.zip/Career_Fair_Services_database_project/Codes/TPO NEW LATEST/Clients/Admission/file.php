<div width="100%" height="80%" style="margin:10px 10px;border:5px double #4799dc;color:black;font-family:bold;">
	<div style="padding-left:270px;font-size:20px;float:center;margin:10px;">
		ILLINOIS INSTITUTE OF TECHNOLOGY
	</div>
	<div style="padding-left:130px;font-size:20px;margin:10px;">
		10 W 35th St, Chicago, IL 60616
	</div>
	<div style="padding-left:310px;font-size:20px;margin:10px;">
		STATEMENT OF MARKS/GRADE
	</div>
</div>
