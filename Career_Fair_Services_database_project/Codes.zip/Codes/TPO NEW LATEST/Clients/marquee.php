<div>
<img style="border:  2px solid #4799dc;" src="http://www.commonapp.org/files/school/image/Illinois%20Institute%20of%20Technology_Campus_945x350_60k_Logo_8.17.15.jpg" name="slide" border=0 width=100% height=210/>
</div>