<?php

include "../header.php"; 

?>

<h1><a href='pdf.php'>Click here to generate PDF</a></h1>