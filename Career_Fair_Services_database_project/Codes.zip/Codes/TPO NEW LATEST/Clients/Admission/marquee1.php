<div width="100%" height="80%" style="margin:10px 10px;border:5px double #4799dc;color:black;font-family:bold;">
	<div width="100%" style="font-size:25px;border:5px double #4799dc;float:left;">
		<div style="margin:12px 10px;font-size:25px;">
			<img src="https://upload.wikimedia.org/wikipedia/en/thumb/9/96/Illinois_Institute_of_Technology_%28seal%29.svg/1200px-Illinois_Institute_of_Technology_%28seal%29.svg.png" style="width:100px;height:100px;">
		</div>
	</div>
	<div style="padding-left:330px;font-size:20px;float:center;margin:10px;">
		ILLINOIS INSTITUTE OF TECHNOLOGY
	</div>
	<!--<div style="padding-left:270px;font-size:25px;margin:10px;">
		
	</div>
	<div style="padding-left:270px;font-size:25px;margin:10px;">
		
	</div>-->
	<div style="padding-left:230px;font-size:15px;margin:10px;">
		10 W 35th St, Chicago, IL 60616
	</div>
</div>
<div width="100%" height="80%" style="margin:10px 10px;font-size:25px;border:5px double #4799dc;color:black;font-family:bold;">
	<div style="margin:10px 10px;padding-left:20px;">
		APPLICATION FOR REGISTRATION/ADMISSION TO MASTERS COURSE
	</div>
</div>
