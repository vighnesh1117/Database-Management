<marquee behavior="alternate" border="2px solid blue" width="100%" 
style="border:5px double #4799dc;"  loop="-1" direction="left" scrollamount="8">
		<img style="border:  2px solid #4799dc;" src="http://www.cs.iit.edu/~scs/IIT-IBM/images/iit.gif" name="slide" border=0 width=50% height=80/>
		
</marquee>