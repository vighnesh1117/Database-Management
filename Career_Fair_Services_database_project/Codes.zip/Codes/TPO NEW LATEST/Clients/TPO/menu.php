<ul>
  <li <?php if($n==2){ echo "class=\"active\"";}?>><a href="frmRegistration.php">Current Profile</a></li>
  <li <?php if($n==6){ echo "class=\"active\"";}?>><a href="frmInterviewAdd.php">Arrange Campus</a></li>
  <li <?php if($n==3){ echo "class=\"active\"";}?>><a href="frmInterviews.php">Interviews</a></li>
  <li <?php if($n==5){ echo "class=\"active\"";}?>><a href="frmMail.php">Mail To</a></li>
  <li ><a href="checkLogout.php">Logout</a></li>
</ul>