<ul>
  <li <?php if($n==1){ echo "class=\"active\"";}?>><a href="frmTeacherHome.php">Your Profile</a></li>
  <li <?php if($n==2){ echo "class=\"active\"";}?>><a href="frmViewStudentlist.php">View Student</a></li>
  <li <?php if($n==3){ echo "class=\"active\"";}?>><a href="frmViewCampuslist.php">View Campus</a></li>
  <li <?php if($n==4){ echo "class=\"active\"";}?>><a href="eligiblestud.php">Candidates</a></li>
  <li <?php if($n==5){ echo "class=\"active\"";}?>><a href="frmaddmarks.php">Add Marks</a></li>
  <li ><a href="checkLogout.php">Logout</a></li>
</ul>