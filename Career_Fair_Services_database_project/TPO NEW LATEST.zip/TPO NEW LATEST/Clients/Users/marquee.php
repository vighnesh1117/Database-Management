<marquee behavior="" border="2px solid blue" width="100%" 
style="border:  5px double #4799dc;"  loop="-1" direction="left" scrollamount="8">
		<img style="border:  2px solid #4799dc;" src="../../images/111.jpg" name="slide" border=0 width=50% height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/1a.jpg" name="slide" border=0 width=100 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/1.jpg" name="slide" border=0 width=80 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/1b.jpg" name="slide" border=0 width=100 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/2.jpg" name="slide" border=0 width=120 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/3.jpg" name="slide" border=0 width=100 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/4.jpg" name="slide" border=0 width=100 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/5.jpg" name="slide" border=0 width=110 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/7.jpg" name="slide" border=0 width=110 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/9.jpg" name="slide" border=0 width=110 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/10.jpg" name="slide" border=0 width=100 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/13.jpg" name="slide" border=0 width=100 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/11.jpg" name="slide" border=0 width=100 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/12.jpg" name="slide" border=0 width=100 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/14.jpg" name="slide" border=0 width=100 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/15.jpg" name="slide" border=0 width=100 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/16.jpg" name="slide" border=0 width=100 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/17.jpg" name="slide" border=0 width=100 height=80/>
		<img style="border:  2px solid #4799dc;" src="../../images/18.jpg" name="slide" border=0 width=100 height=80 />
		<img style="border:  2px solid #4799dc;" src="../../images/19.jpg" name="slide" border=0 width=100 height=80 />
		<img style="border:  2px solid #4799dc;" src="../../images/20.jpg" name="slide" border=0 width=100 height=80 />
	  </marquee>