<div width="100%" height="80%" style="margin:10px 10px;border:5px double #4799dc;color:black;font-family:bold;">
	<div style="padding-left:270px;font-size:20px;float:center;margin:10px;">
		JAWAHAR EDUCATION SOCIETY'S
	</div>
	<div style="padding-left:130px;font-size:20px;margin:10px;">
		A.C.PATIL COLLEGE OF ENGINEERING,KHARGAR NAVI-MUMBAI
	</div>
	<div style="padding-left:310px;font-size:20px;margin:10px;">
		STATEMENT OF MARKS
	</div>
</div>
