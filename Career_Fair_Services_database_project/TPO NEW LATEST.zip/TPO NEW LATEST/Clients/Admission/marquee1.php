<div width="100%" height="80%" style="margin:10px 10px;border:5px double #4799dc;color:black;font-family:bold;">
	<div width="100%" style="font-size:25px;border:5px double #4799dc;float:left;">
		<div style="margin:12px 10px;font-size:25px;">
			<img src="../../images/acpatillogo.jpg" style="width:100px;height:100px;">
		</div>
	</div>
	<div style="padding-left:330px;font-size:20px;float:center;margin:10px;">
		JAWAHAR EDUCATION SOCIETY'S
	</div>
	<div style="padding-left:270px;font-size:25px;margin:10px;">
		A.C.PATIL COLLEGE OF ENGINEERING 
	</div>
	<div style="padding-left:270px;font-size:25px;margin:10px;">
		MANAGEMENT STUDIES & RESEARCH
	</div>
	<div style="padding-left:230px;font-size:15px;margin:10px;">
		Plot No. 17, Sector-4, Khargar. Opp. Khargar Rly. Stn. Khargar Navi Mumbai- 410 210.
	</div>
</div>
<div width="100%" height="80%" style="margin:10px 10px;font-size:25px;border:5px double #4799dc;color:black;font-family:bold;">
	<div style="margin:10px 10px;padding-left:20px;">
		APPLICATION FOR REGISTRATION/ADMISSION TO DEGREE COURSE
	</div>
</div>
