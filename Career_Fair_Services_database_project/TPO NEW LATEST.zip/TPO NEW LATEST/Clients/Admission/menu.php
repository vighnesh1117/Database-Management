<ul>
   <li <?php if($n==1){ echo "class=\"active\"";}?>><a href="../Home/frmHomePage.php">Home</a></li>
   <li <?php if($n==5){ echo "class=\"active\"";}?>><a href="../Admin/frmAdmin.php">Admin Login</a></li>
   <li <?php if($n==2){ echo "class=\"active\"";}?>><a href="../TPO/frmlogin.php">TPO Login</a></li>
   <li <?php if($n==3){ echo "class=\"active\"";}?>><a href="../Users/frmUsers.php">Student Login</a></li>
   <li <?php if($n==6){ echo "class=\"active\"";}?>><a href="../Teacher/frmTeacher.php">Teacher Login</a></li>
   <li <?php if($n==7){ echo "class=\"active\"";}?>><a href="../Admission/admissionprocess.php">Admission Form</a></li>
   <!--<li <?php if($n==4){ echo "class=\"active\"";}?>><a href="../Contact/frmContact.php">Contact Us</a></li>-->
</ul>