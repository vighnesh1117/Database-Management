<ul>
  <!--<li <?php if($n==1){ echo "class=\"active\"";}?>><a href="frmAdminHome.php">Home</a></li>
  <li <?php if($n==6){ echo "class=\"active\"";}?>><a href="frmnewcompany.php">New Request</a></li>
  <li <?php if($n==2){ echo "class=\"active\"";}?>><a href="frmUsers.php">Users</a></li>
  <li <?php if($n==3){ echo "class=\"active\"";}?>><a href="frmCompanies.php">Companies</a></li>
  <li <?php if($n==4){ echo "class=\"active\"";}?>><a href="frmForums.php">Forums</a></li>
  <li <?php if($n==1){ echo "class=\"active\"";}?>><a href="frmAdminHome.php">Home</a></li>-->
  <li <?php if($n==2){ echo "class=\"active\"";}?>><a href="frmaddstaff.php">Add Staff</a></li>
  <li <?php if($n==3){ echo "class=\"active\"";}?>><a href="frmViewstafflist.php">View Staff</a></li>
  <li <?php if($n==5){ echo "class=\"active\"";}?>><a href="frmMail.php">Mail To</a></li>
  <li ><a href="checkLogout.php">Logout</a></li>
</ul>