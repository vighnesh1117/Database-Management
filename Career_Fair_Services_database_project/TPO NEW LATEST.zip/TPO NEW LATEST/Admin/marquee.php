<marquee behavior="alternate" border="2px solid blue" width="100%" style="border:  5px double #4799dc;"  loop="-1" direction="left" scrollamount="8">
		<img style="border:  2px solid #4799dc;" src="../images/111.jpg" name="slide" border=0 width=50% height=80/>
		<img style="border:  2px solid #4799dc;" src="../images/1a.jpg" name="slide" border=0 width=100 height=80/>
		<img style="border:  2px solid #4799dc;" src="../images/1.jpg" name="slide" border=0 width=80 height=80/>
</marquee>